#include "hanoi.hpp"

// Recursive solution: number of moves = 2^n - 1
std::uint64_t hanoi_moves(int n) {
    if (n <= 0) return 0;      // no disks, no moves
    if (n == 1) return 1;      // base case: 1 disk = 1 move
    return 2 * hanoi_moves(n - 1) + 1; // move n-1 disks, move last disk, move n-1 disks again
}
