#pragma once
#include <cstdint>

// Return exact number of moves for n disks in Tower of Hanoi.
// Constraints: n >= 0. For n==0 return 0.
std::uint64_t hanoi_moves(int n);