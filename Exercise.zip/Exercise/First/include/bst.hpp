#pragma once
#include <memory>

// Minimal binary search tree. No duplicates; ignore duplicate inserts.
struct Node {
    int key;
    std::unique_ptr<Node> l, r;
    explicit Node(int k) : key(k) {}
};

class BST {
public:
    // Insert key k. No effect if k already present.
    void insert(int k);

    // True if k is in the tree.
    bool find(int k) const;

private:
    std::unique_ptr<Node> root;
};
