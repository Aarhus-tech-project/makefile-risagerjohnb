# Opgave
På din Linux maskine skal du færdiggøre koden og skrive en makefile.<br>
I aflevere på github classroom

### Mål

Du har fået et lille C++ projekt med nogle headerfiler i include/ og sourcefiler i src/. Der er også en tom Makefile.<br>
Din opgave er at skrive sourcefilerne og makefilen således at makefilen gør følgende:
- Kompilere hver .cpp til sin egen objektfil (.o)
- Samler en statisk bibliotekfil (.a)
- Linker eksekverbare programmer
- Understøtter debug/release builds
- Kun genbygger det, der er ændret (også når headers ændres)
Lav nyttige hjælpe‐targets til at køre, teste og rydde op.

### Tjekliste
1. Kompilere per fil: hver src/*.cpp → build/*.o.
2. Linke app’en: lav build/app (CLI med --hanoi N og --bst "5,2,7,3").
3. Bygge et statisk bibliotek: build/libclassics.a fra dine algoritme-objekter (hanoi.o, bst.o) og link både app og tests imod det.
4. Bygge tests: lav build/tests ud fra tests/tests.cpp + dit statiske bibliotek.
5. Understøtte buildtyper: make debug (fx -Og -g) og make release (fx -O2 -DNDEBUG).
6. Generere header-afhængigheder automatisk: brug -MMD -MP og -include, så header-ændringer udløser korrekt genkompilering.
7. Have hjælpe-targets: run, test, clean (marker dem med .PHONY).
8. Du skal forklare dine valg i din makefile enten med kommentarere eller med et lille tekst dokument.

Du skal altså ende med at kunne køre følgende komandoer og de skal virke.
```bash
make              # standard (debug) build af app + tests + lib
make run          # kører ./build/app med et fornuftigt default (fx --hanoi 10)
make test         # kører ./build/tests (asserts skal bestå)
make release      # bygger optimeret release-version
make clean        # sletter build/-artefakter
```

### Hjælp
For at du kan kompile dit program og bruge make skal du have installeret de nødvendige tools på din Linux maskine.<br>
Det er: g++, make og ar. På Ubuntu kan det gøres med "sudo apt install -y build-essential"

Hvis du bruger f.eks. VS Code være opmærksom på at TAB er TAB og ikke mellemrum og LF linjeafslutninger (ikke CRLF).<br>
Du kan bruge de 3 eksempler til at hjælpe dig med at bygge en makefile.<br>
Du kan også bruge følgende site https://makefiletutorial.com/ eller andre hjælpemidler.

Du kan bruge følgende til at lave en selvkontrol
```bash
# 1) Kun main.cpp ændret → kun main.o bør bygges, derefter link
touch src/main.cpp
make -n

# 2) En header ændret → alle objekter der inkluderer den bør bygges
touch include/bst.hpp
make -n

# 3) Kun hanoi.cpp ændret → kun hanoi.o bør bygges, derefter link
touch src/hanoi.cpp
make -n

# 4) Release adskiller sig fra Debug (typisk mindre/færre symboler)
make clean && make           # debug
ls -lh build/
make clean && make release   # release
ls -lh build/
```
